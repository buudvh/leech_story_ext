load('libs.js');
load('config.js');

function execute(url, page) {
    return Response.success([{
        name: '苟在初圣魔门当人材'.convertT2S(),
        link: 'http://www.60ksw.com/ks/220/220051/index.html',
    }]);
}