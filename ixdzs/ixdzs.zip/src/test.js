load('libs.js');
load('config.js');

function execute(url, page) {
    return Response.success([{
        name: '全民轉職：死靈法師！我即是天災'.convertT2S(),
        link: "https://ixdzs.tw/read/551252/",
        cover: 'https://img22.ixdzs.com/59/00/59004f4ee6b3d21e443e71fb91d7fb31.jpg',
    }]);
}