function execute() {
    return Response.success([
        { title: "Home", input: "https://69shuba.tw/", script: "test.js" },
        { title: "Home", input: `
            <div class="side_commend" style="width:100%;">
                    <p class="title"><i class="fa fa-user-circle-o">&nbsp;</i> 仙俠玄幻今日推薦</p>
                    <ul class="flex">
                                                                <li class="searchresult">
                        <div class="img_span">
                            <a href="/book/31676.html"><img class="lazy" src="https://cdn.69shu.tw/31/31676/31676s.jpg" data-original="https://cdn.69shu.tw/31/31676/31676s.jpg" title="和女星荒島同居的日子" style=""><span class="full">仙俠 / 全本</span></a>
                        </div>
                        <div>
                            <a href="/book/31676.html"><h3>和女星荒島同居的日子</h3></a>
                            <p><i class="fa fa-user-circle-o">&nbsp;</i>懸劍&nbsp;&nbsp;<span class="s_gray">151 萬字&nbsp;&nbsp;2018-12-26</span></p>
                            <p class="searchresult_p"> 遊輪失事，我和性感女星流落荒島。她為了生存，懷了我的孩子…… </p>
                            <p><a href="/book/31676/10331994.html">第519章 南柯一夢？【大結局】</a></p>
                        </div>
                    </li>
                                            <li class="searchresult">
                        <div class="img_span">
                            <a href="/book/1681.html"><img class="lazy" src="https://cdn.69shu.tw/1/1681/1681s.jpg" data-original="https://cdn.69shu.tw/1/1681/1681s.jpg" title="素女仙緣" style=""><span>仙俠 / 連載</span></a>
                        </div>
                        <div>
                            <a href="/book/1681.html"><h3>素女仙緣</h3></a>
                            <p><i class="fa fa-user-circle-o">&nbsp;</i>優婆瓔珞&nbsp;&nbsp;<span class="s_gray">230 萬字&nbsp;&nbsp;2020-07-16</span></p>
                            <p class="searchresult_p"> 她是一個普通的凡人女子，卻偶得機緣，得到一本仙家功法，從此走上一條尋仙求道之路。仙路漫漫，危險重重，她能否一路披荊斬棘，尋得大道？天道無情、人性自私，修真者本是逆天之人，是否要真要同天一般無情？而她又能否走出一條不同尋常的修仙路？ </p>
                            <p><a href="/book/1681/470697.html">第1156章</a></p>
                        </div>
                    </li>
                                            <li class="searchresult">
                        <div class="img_span">
                            <a href="/book/34748.html"><img class="lazy" src="https://cdn.69shu.tw/34/34748/34748s.jpg" data-original="https://cdn.69shu.tw/34/34748/34748s.jpg" title="九天神皇" style=""><span class="full">仙俠 / 全本</span></a>
                        </div>
                        <div>
                            <a href="/book/34748.html"><h3>九天神皇</h3></a>
                            <p><i class="fa fa-user-circle-o">&nbsp;</i>蒼狼望月&nbsp;&nbsp;<span class="s_gray">484 萬字&nbsp;&nbsp;2020-08-14</span></p>
                            <p class="searchresult_p"> 楊羽重生到五百年之後，身懷絕世功法的他，注定不會默默無聞。他的重生，又將會有多少天縱奇才，英雄豪傑為之顫栗…… </p>
                            <p><a href="/book/34748/76089077.html">第1860章：大結局</a></p>
                        </div>
                    </li>
                                            <li class="searchresult">
                        <div class="img_span">
                            <a href="/book/31773.html"><img class="lazy" src="https://cdn.69shu.tw/31/31773/31773s.jpg" data-original="https://cdn.69shu.tw/31/31773/31773s.jpg" title="非常獵人" style=""><span>仙俠 / 連載</span></a>
                        </div>
                        <div>
                            <a href="/book/31773.html"><h3>非常獵人</h3></a>
                            <p><i class="fa fa-user-circle-o">&nbsp;</i>瑞恩&nbsp;&nbsp;<span class="s_gray">1120 萬字&nbsp;&nbsp;4個月前</span></p>
                            <p class="searchresult_p"> 八分之一兔人血統的獵人傳奇 </p>
                            <p><a href="/book/31773/37278357.html">288章 進擊的獸人（五）</a></p>
                        </div>
                    </li>
                                            <li class="searchresult">
                        <div class="img_span">
                            <a href="/book/145415.html"><img class="lazy" src="https://cdn.69shu.tw/145/145415/145415s.jpg" data-original="https://cdn.69shu.tw/145/145415/145415s.jpg" title="不敗封神" style=""><span>仙俠 / 連載</span></a>
                        </div>
                        <div>
                            <a href="/book/145415.html"><h3>不敗封神</h3></a>
                            <p><i class="fa fa-user-circle-o">&nbsp;</i>歐八爺&nbsp;&nbsp;<span class="s_gray">190 萬字&nbsp;&nbsp;2019-11-16</span></p>
                            <p class="searchresult_p"> 一代蓋世天驕重生於落魄少年身上，而後一飛衝天，以一己之力鎮壓八荒，腳踏九天十地，無數天驕黯淡無光，以凜然之姿不敗封神。 </p>
                            <p><a href="/book/145415/60100664.html">第七百七十八章 最終決戰</a></p>
                        </div>
                    </li>
                                            <li class="searchresult">
                        <div class="img_span">
                            <a href="/book/38786.html"><img class="lazy" src="/static/nocover.jpg" data-original="https://cdn.69shu.tw/38/38786/38786s.jpg" title="最強修仙小學生"><span class="full">仙俠 / 全本</span></a>
                        </div>
                        <div>
                            <a href="/book/38786.html"><h3>最強修仙小學生</h3></a>
                            <p><i class="fa fa-user-circle-o">&nbsp;</i>一言二堂&nbsp;&nbsp;<span class="s_gray">751 萬字&nbsp;&nbsp;2019-09-19</span></p>
                            <p class="searchresult_p"> 身懷混沌道體卻頑劣不馴的神尊淩天，偷了葬劍閣和萬寶宗的寶庫，被師傅逍遙神祖踢下界，萬萬沒想到，卻重生在了一個小學生身上，在重新曆練的路上，一連串啼笑皆非的故事。別看我還是個孩子，想欺負我？打得你滿地找牙！別看我還是個小學生，想坑我？坑得你哭天喊地！ </p>
                            <p><a href="/book/38786/43569713.html">第三千零六十八章 大結局（下）</a></p>
                        </div>
                    </li>
                                            <li class="searchresult">
                        <div class="img_span">
                            <a href="/book/32832.html"><img class="lazy" src="/static/nocover.jpg" data-original="https://cdn.69shu.tw/32/32832/32832s.jpg" title="修真醫聖在都市"><span class="full">仙俠 / 全本</span></a>
                        </div>
                        <div>
                            <a href="/book/32832.html"><h3>修真醫聖在都市</h3></a>
                            <p><i class="fa fa-user-circle-o">&nbsp;</i>超級老豬&nbsp;&nbsp;<span class="s_gray">530 萬字&nbsp;&nbsp;2020-09-01</span></p>
                            <p class="searchresult_p"> 俗世修行，紅塵磨礪，大道至簡，不破不立！趙一凡，入世修煉，體驗人間百態。軟萌妹紙卻天天纏在他身旁，麵對這種情況，趙一凡隻想說一句：“小姐姐，你饒了我吧，其實我是來修煉的……” </p>
                            <p><a href="/book/32832/76097743.html">第一千三百七十三章 大結局（全書完）</a></p>
                        </div>
                    </li>
                                            <li class="searchresult">
                        <div class="img_span">
                            <a href="/book/31232.html"><img class="lazy" src="/static/nocover.jpg" data-original="https://cdn.69shu.tw/31/31232/31232s.jpg" title="天逆"><span>仙俠 / 連載</span></a>
                        </div>
                        <div>
                            <a href="/book/31232.html"><h3>天逆</h3></a>
                            <p><i class="fa fa-user-circle-o">&nbsp;</i>陳輝&nbsp;&nbsp;<span class="s_gray">425 萬字&nbsp;&nbsp;2020-06-29</span></p>
                            <p class="searchresult_p"> 轉涅盤，天玄指天！度生死，淬煉靈丹！破乾坤，為見伊人一麵；掌輪回，隻換你的笑顏！ </p>
                            <p><a href="/book/31232/9754485.html">【番外】第六十七章 雷劫淬體</a></p>
                        </div>
                    </li>
                                            <li class="searchresult">
                        <div class="img_span">
                            <a href="/book/1290.html"><img class="lazy" src="/static/nocover.jpg" data-original="https://cdn.69shu.tw/1/1290/1290s.jpg" title="武神大帝"><span>仙俠 / 連載</span></a>
                        </div>
                        <div>
                            <a href="/book/1290.html"><h3>武神大帝</h3></a>
                            <p><i class="fa fa-user-circle-o">&nbsp;</i>十裏&nbsp;&nbsp;<span class="s_gray">311 萬字&nbsp;&nbsp;2018-10-11</span></p>
                            <p class="searchresult_p"> 為了救人他意外重生，從此開啟風騷異界之旅，收寵物？泡美妞？集神器？NONONO，無數神寵找上門，各色美女主動送，萬千神器求認主，這才是武神大帝！&lt;/p&gt; </p>
                            <p><a href="/book/1290/347531.html">第832章 祝福！</a></p>
                        </div>
                    </li>
                                            <li class="searchresult">
                        <div class="img_span">
                            <a href="/book/31982.html"><img class="lazy" src="/static/nocover.jpg" data-original="https://cdn.69shu.tw/31/31982/31982s.jpg" title="最強修煉係統"><span>仙俠 / 連載</span></a>
                        </div>
                        <div>
                            <a href="/book/31982.html"><h3>最強修煉係統</h3></a>
                            <p><i class="fa fa-user-circle-o">&nbsp;</i>爆炒魚子醬&nbsp;&nbsp;<span class="s_gray">418 萬字&nbsp;&nbsp;2020-06-29</span></p>
                            <p class="searchresult_p"> 遊戲玩家王浩，帶著九龍係統穿越元武大陸，從此踩天才，滅凶獸，懷摟絕世美女，成就無上霸業！ </p>
                            <p><a href="/book/31982/10591816.html">第999章 虛空之主</a></p>
                        </div>
                    </li>
                                        </ul>
                </div>
            `, script: "recommend.js" },
        // { title: "玄幻", input: "/fenlei/xuanhuan/1/", script: "gen2.js" },
        // { title: "仙侠", input: "/fenlei/wuxia/1/", script: "gen2.js" },
        // { title: "都市", input: "/fenlei/dushi/1/", script: "gen2.js" },
        // { title: "歷史", input: "/fenlei/lishi/1/", script: "gen2.js" },
        // { title: "遊戲", input: "/fenlei/youxi/1/", script: "gen2.js" },
        // { title: "科幻", input: "/fenlei/kehu/1/", script: "gen2.js" },
        // { title: "女生", input: "/fenlei/kongbu/1/", script: "gen2.js" },
        // { title: "其他", input: "/fenlei/qita/1/", script: "gen2.js" },
    ]);
}