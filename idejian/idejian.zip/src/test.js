load('libs.js');
load('config.js');

function execute(url, page) {
    return Response.success([{
        name: '叛出宗门后，偏心师尊跪求原谅',
        link: 'https://www.idejian.com/book/13451251/',
        cover: 'https://bookbk.img.zhangyue01.com/idc_1/m_1,w_300,h_400/6fcf06db/group62/Kw/YR/fb8dc6dfbd2048d60dc120bf213c197c.jpg?v=4rNiCsrU&t=fwAAAWi2YAA.',
        host: BASE_URL
    }]);
}