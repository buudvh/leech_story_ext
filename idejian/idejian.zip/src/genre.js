function execute() {
    return Response.success([
        { title: "男-奇幻", input: "/books/nansheng?categoryId=1114", script: "zen.js" },
        { title: "男-玄幻", input: "/books/nansheng?categoryId=1115", script: "zen.js" },
        { title: "男-武侠", input: "/books/nansheng?categoryId=1116", script: "zen.js" },
        { title: "男-仙侠", input: "/books/nansheng?categoryId=1117", script: "zen.js" },
        { title: "男-都市", input: "/books/nansheng?categoryId=1118", script: "zen.js" },
        { title: "男-校园", input: "/books/nansheng?categoryId=1119", script: "zen.js" },
        { title: "男-历史", input: "/books/nansheng?categoryId=1120", script: "zen.js" },
        { title: "男-军事", input: "/books/nansheng?categoryId=1121", script: "zen.js" },
        { title: "男-游戏", input: "/books/nansheng?categoryId=1122", script: "zen.js" },
        { title: "男-竞技", input: "/books/nansheng?categoryId=1123", script: "zen.js" },
        { title: "男-科幻", input: "/books/nansheng?categoryId=1124", script: "zen.js" },
        { title: "男-灵异", input: "/books/nansheng?categoryId=1125", script: "zen.js" },
        { title: "女-现代言情", input: "/books/nvsheng?categoryId=1126", script: "zen.js" },
        { title: "女-古代言情", input: "/books/nvsheng?categoryId=1127", script: "zen.js" },
        { title: "女-幻想言情", input: "/books/nvsheng?categoryId=1128", script: "zen.js" },
        { title: "女-青春校园", input: "/books/nvsheng?categoryId=1129", script: "zen.js" },
        { title: "女-同人作品", input: "/books/nvsheng?categoryId=1130", script: "zen.js" },
        { title: "女-惊悚恐怖", input: "/books/nvsheng?categoryId=1132", script: "zen.js" },
        { title: "女-次元专区", input: "/books/nvsheng?categoryId=1133", script: "zen.js" },
    ]);
}
