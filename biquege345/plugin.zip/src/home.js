function execute() {
    return Response.success([
        {title: "首页", input: "https://www.biquge345.com/", script: "gen.js"}
    ]);
}