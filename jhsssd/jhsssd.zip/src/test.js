load('libs.js');
load('config.js');

function execute(url, page) {
    return Response.success([{
        name: '让你设计装备，你给我搞科幻？'.convertT2S(),
        link: 'https://m.jhsssd.com/116652/',
        cover: 'https://m.jhsssd.com/files/article/image/116/116485/116485s.jpg',
    }]);
}