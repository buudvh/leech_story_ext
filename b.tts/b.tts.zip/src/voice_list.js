let voices = [
    {id: "vi-VN-HoaiMyNeural;Female", language: "vi-VN"},
    {id: "vi-VN-NamMinhNeural;Male", language: "vi-VN"},
]