load('libs.js');
load('config.js');

function execute(url, page) {
    return Response.success([
        {
            name: '萬世之名',
            link: 'https://sto55.com/book/41488/',
            cover: 'https://sto55.com/files/article/image/41/41488/41488s.jpg',
            host: BASE_URL
        }
    ]);
}