load('libs.js');
load('config.js');

function execute(url, page) {
    return Response.success([{
        name: '無始皇手諭，不得出銀河邊關'.convertT2S(),
        link: 'https://www.novels.com.tw/novels/noc4587bf22f7e1cead2c076181f91a3ae2653822b0d6c0a0c3a45e27b57f9fb2d/?aid=676795',
        cover: 'http://www.novels.com.tw/images/676/676795/676795s.jpg',
    }]);
}