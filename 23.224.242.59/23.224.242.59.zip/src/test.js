load('libs.js');
load('config.js');

function execute(url) {
    return Response.success([{
        name: '夜无疆',
        link: 'http://23.224.242.59/book/99467/',
        cover: 'http://www.2wxsi.com/files/article/image/99/99467/99467s.jpg',
        description: '那一天太阳落下再也没有升起……',
        host: BASE_URL
    }]);
}