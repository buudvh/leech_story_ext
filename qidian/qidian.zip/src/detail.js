load('libs.js');

//Get infor from stv
function execute(url) {
    try {
        if (!url.includes("sangtac") && !url.includes("14.225.254.182") && !url.includes("103.82.20.93")) {
            url = STVHOST + "/truyen/qidian/1/" + url.match(/\/book\/(\d+)(?:\/|$)/)[1] + "/";
        } else {
            url = STVHOST + "/truyen/qidian/1/" + url.match(/\/(\d+)\/?$/)[1] + "/";
        }
        var idBook = getBookId(url);
        let response = fetch(url + '/');
        let doc = response.html();
        var author = doc.select("i.cap").attr("onclick").replace(/location=\'\/\?find\=&findinname\=(.*?)\'/g, "$1");
        let des = doc.select(".blk:has(.fa-water) .blk-body").html();

        var cover = doc.select('meta[property="og:image"]').first().attr("content").replace("/cdn/images/nc.jpg", "https://static.sangtacvietcdn.xyz/img/bookcover256.jpg")

        return Response.success({
            name: doc.select("#oriname").text(),
            cover: cover,
            author: author || 'Unknow',
            description: des,
            detail: "BookId: " + idBook
                + "\nChương mới: " + doc.select("#lastupdatetime").text(),
            ongoing: true,
            host: STVHOST,
            comments: [
                {
                    title: "评论",
                    input: idBook,
                    script: "comment.js"
                }
            ],
        });
    } catch (error) {
        return Response.error('fetch ' + url + ' failed: ' + error.message);
    }
}