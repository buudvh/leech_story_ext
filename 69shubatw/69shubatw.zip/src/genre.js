function execute() {
    return Response.success([
        { title: "诸天", input: "诸天", script: "search.js" },
        { title: "聊天群", input: "聊天群", script: "search.js" },
        { title: "万界", input: "万界", script: "search.js" },
        { title: "无限", input: "无限", script: "search.js" },

        { title: "吞噬", input: "吞噬", script: "search.js" },
        { title: "吞噬", input: "吞噬", script: "search.js" },
        { title: "完美世界", input: "完美世界", script: "search.js" },
        { title: "遮天", input: "遮天", script: "search.js" },
        { title: "圣墟", input: "圣墟", script: "search.js" },
        { title: "一世之尊", input: "一世之尊", script: "search.js" },
        { title: "西游", input: "西游", script: "search.js" },
        { title: "大奉", input: "大奉", script: "search.js" },
        { title: "轮回", input: "轮回", script: "search.js" },
        { title: "庆余年", input: "庆余年", script: "search.js" },
        { title: "斗罗", input: "斗罗", script: "search.js" },
        { title: "妖神记", input: "妖神记", script: "search.js" },

        { title: "玄幻", input: "/fenlei/xuanhuan/1/", script: "gen2.js" },
        { title: "仙侠", input: "/fenlei/wuxia/1/", script: "gen2.js" },
        { title: "都市", input: "/fenlei/dushi/1/", script: "gen2.js" },
        { title: "歷史", input: "/fenlei/lishi/1/", script: "gen2.js" },
        { title: "遊戲", input: "/fenlei/youxi/1/", script: "gen2.js" },
        { title: "科幻", input: "/fenlei/kehu/1/", script: "gen2.js" },
        { title: "女生", input: "/fenlei/kongbu/1/", script: "gen2.js" },
        { title: "其他", input: "/fenlei/qita/1/", script: "gen2.js" },
    ]);
}
