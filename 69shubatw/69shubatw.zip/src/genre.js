function execute() {
    return Response.success([
        { title: "玄幻", input: "/fenlei/xuanhuan/1/", script: "gen2.js" },
        { title: "仙侠", input: "/fenlei/wuxia/1/", script: "gen2.js" },
        { title: "都市", input: "/fenlei/dushi/1/", script: "gen2.js" },
        { title: "歷史", input: "/fenlei/lishi/1/", script: "gen2.js" },
        { title: "遊戲", input: "/fenlei/youxi/1/", script: "gen2.js" },
        { title: "科幻", input: "/fenlei/kehu/1/", script: "gen2.js" },
        { title: "女生", input: "/fenlei/kongbu/1/", script: "gen2.js" },
        { title: "其他", input: "/fenlei/qita/1/", script: "gen2.js" },
    ]);
}
