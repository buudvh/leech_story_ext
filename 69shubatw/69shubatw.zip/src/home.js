function execute() {
    return Response.success([
        { title: "Home", input: "https://69shuba.tw/", script: "gen.js" },
    ]);
}