load('libs.js');
load('config.js');

function execute(url, page) {
    return Response.success([{
        name: '一世之尊，从遮天伏羲开始',
        link: 'https://www.1qxs.com/xs_q0aw3s/88202.html',
        cover: 'https://img.1qxs.com/cover/88202.webp',
    }]);
}