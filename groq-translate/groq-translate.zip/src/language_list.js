let languages = [
    {"id": "zh", "name": "Trung"},
    {"id": "en", "name": "Anh"},
    {"id": "vi", "name": "Việt (Tiêu chuẩn)"},
    {"id": "vi_sac", "name": "Việt (Truyện Sắc)"},
    {"id": "vi_vietlai", "name": "Việt (Viết Lại Convert)"}
];