load("config.js");
load("libs.js");

function execute(url, page) {
    try {
        page = page || '0';
        var ignores = [
            "nhanh xuyên",
            "ngôn tình",
            "ác nữ"
        ].join(",");
        var ignoresConfig = localStorage.getItem("IGNORES") || "";

        url = `${STV_HOST}/io/searchtp/searchBooks?find=&host=fanqie&minc=0&tag=${url == "" ? "&sort=update" : url}`;
        var response = fetch(url, {
            "body": `ignores=${encodeURIComponent(ignores + ignoresConfig)}`,
            "method": "POST",
        });

        if (!response.ok) throw new Error(`Status = ${response.status}`);

        // var html = `
        // <!DOCTYPE html>
        // <html lang="vi">
        // <head>
        //     <meta charset="UTF-8">
        //     <meta name="viewport" content="width=device-width, initial-scale=1.0">
        //     <title>Document</title>
        // </head>
        // <body>
        //     ${response.text()}
        // </body>
        // </html>
        // `;

        // var doc = Html.parse(html);
        var doc = response.html();
        var next = (parseInt(page, 10) + 1).toString();
        var el = doc.select("a.booksearch");

        if (!el.length) throw new Error("Length = 0");

        var data = [];
        el.forEach(function (e) {
            var stv_story_link = e.select("a").first().attr("href");
            var bookid = stv_story_link.split("/")[4];
            var tag = e.select("div > span.searchtag").first().text().trim();

            // if (tag != "Fanqie") return;

            data.push({
                name: toCapitalize(e.select(".searchbooktitle").first().text()),
                link: `${BASE_URL}/page/${bookid}`,
                cover: e.select("img").first().attr("src"),
                description: e.select("div > span.searchtag").first().text() + "|" + e.select("div > span.searchbookauthor").first().text()
                    + "\n" + e.select("div > span.lhr").last().text(),
            });
        });

        return Response.success(data, next);
    } catch (error) {
        return Response.error(`Url: ${url} \nMessage: ${error.message}`);
    }
}
