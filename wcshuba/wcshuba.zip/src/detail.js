load('libs.js');
load('config.js');

function execute(url) {
    try {
        var response = crawler.get(url);
        if (!response.ok) throw new Error(`Status ${response.status}`)

        var doc = response.html();
        var authorElm = doc.select('#wrapper > main > div > div.rank.mt10.pc-only > div.left > div > div > div.booktitle > h2 > a');
        var bookName = doc.select('#wrapper > main > div > div.rank.mt10.pc-only > div.left > div > div > div.booktitle > h1 > a').text().convertT2S();
        var genreElm = doc.select("#wrapper > main > div > div.rank.mt10.pc-only > div.left > div > div > div.bookintro > p:nth-child(1) > a");

        var genres = [];
        genreElm.forEach(element => {
            genres.push({
                title: element.text(),
                input: element.attr("href"),
                script: "tag.js"
            });
        });

        var chapterCount = doc.select("#wrapper > main > div > div.chapterlist.mt10.pc-only > div.all > h3").text().replace(/.*?(【共\d+章】).*/, '$1');

        return Response.success({
            name: bookName.formatTocName(),
            cover: doc.select("#wrapper > main > div > div.rank.mt10.pc-only > div.left > div > a > img").first().attr("src") || DEFAULT_COVER,
            author: authorElm.text(),
            description: chapterCount + "\n"
                + doc.select('#wrapper > main > div > div.rank.mt10.pc-only > div.left > div > div > div.bookintro > p:nth-child(2)').html().cleanHtml().replace(/([.!?…]+)/g, function (match) {
                    return match + "\n";
                }),
            detail: doc.select("#wrapper > main > div > div.rank.mt10.pc-only > div.left > div > div > div.bookdes > p:nth-child(4)").text().convertT2S()
                + `\n${doc.select("#wrapper > main > div > div.rank.mt10.pc-only > div.left > div > div > div.bookdes > p:nth-child(3)").text().convertT2S()}`,
            host: BASE_URL,
            suggests: [
                {
                    title: "同作者",
                    input: authorElm.attr("href"),
                    script: "author.js"
                }
            ],
            genres: genres,
            comments: [
                {
                    title: "QQ Comments",
                    input: bookName,
                    script: "comment.js"
                }
            ]
        });
    } catch (error) {
        return Response.error(`Url ${url} \nMessage: ${error.message}`);
    }
}