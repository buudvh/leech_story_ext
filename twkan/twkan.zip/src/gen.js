load('libs.js');
load('config.js');


//Get review
function execute(url) {
    try {
        var data = [];
        // var response = fetch(url);
        // if (!response.ok) throw new Error(`Status ${response.status}`)

        // var doc = response.html();

        var browser = Engine.newBrowser(); // Khởi tạo browser
        browser.launch(url, 5000); // Mở trang web với timeout
        var doc = browser.html();
        browser.close();

        var elms = doc.select("div.review-list > div.review-item");

        if (!elms.length) throw new Error(`Length = 0`);

        elms.forEach(function (e) {
            data.push({
                name: convertT2S(e.select('div.c_tag > span.c_label').first().text()),
                link: e.select(".rank_right a").first().attr("href"),
                cover: buildCoverUrl(e.select(".rank_right a").first().attr("href")) || DEFAULT_COVER,
                description: convertT2S(e.select(".review-text").first().text()),
                host: BASE_URL
            });
        });

        return Response.success(data);
    } catch (error) {
        return Response.error(`fetch ${url} failed: ${error.message}`);
    }
}