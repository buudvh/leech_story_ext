load('libs.js');
load('config.js');

function execute(url) {
    return Response.success([{
        name: convertT2S('苟在初聖魔門當人材'),
        link: 'https://twkan.com/book/78813.html',
        cover: 'https://twkan.com/files/article/image/78/78813/78813s.jpg',
        description: convertT2S('作者：佚名'),
    }]);
}