function execute() {
    return Response.success([
        { title: "All", input: "https://twkan.com/novels/class/0_1.html", script: "gen2.js" },
        { title: "動漫同人", input: "https://twkan.com/novels/class/9_1.html", script: "gen2.js" },
        { title: "玄幻奇幻", input: "https://twkan.com/novels/class/1_1.html", script: "gen2.js" },
        { title: "武俠仙俠", input: "https://twkan.com/novels/class/2_1.html", script: "gen2.js" },
        { title: "現代都市", input: "https://twkan.com/novels/class/3_1.html", script: "gen2.js" },
        { title: "歷史軍事", input: "https://twkan.com/novels/class/4_1.html", script: "gen2.js" },
        { title: "科幻小說", input: "https://twkan.com/novels/class/5_1.html", script: "gen2.js" },
        { title: "遊戲競技", input: "https://twkan.com/novels/class/6_1.html", script: "gen2.js" },
        { title: "恐怖靈異", input: "https://twkan.com/novels/class/7_1.html", script: "gen2.js" },
        { title: "言情小說", input: "https://twkan.com/novels/class/8_1.html", script: "gen2.js" },
        { title: "其他類型", input: "https://twkan.com/novels/class/10_1.html", script: "gen2.js" },
    ]);
}