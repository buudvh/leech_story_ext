load('libs.js');
load('config.js');

function execute(url, page) {
    return Response.success([{
        name: '苟在初圣魔门当人材'.convertT2S(),
        link: 'https://101kks.com/book/9266.html',
    }]);
}