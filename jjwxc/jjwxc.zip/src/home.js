function execute() {
    return Response.success([
        {"title": "Update", "input": "/assort?fw0=0&fbsj0=0&novelbefavoritedcount0=0&yc0=0&xx0=0&mainview1=1&sd0=0&lx0=0&bq=&removebq=&isfinish=0&collectiontypes=ors&searchkeywords=&page={0}&sortType=1", "script": "gen.js"},
        {"title": "New", "input": "/assort?fw0=0&fbsj0=0&novelbefavoritedcount0=0&yc0=0&xx0=0&mainview1=1&sd0=0&lx0=0&bq=&removebq=&isfinish=0&collectiontypes=ors&searchkeywords=&page={0}&sortType=3", "script": "gen.js"},
        {"title": "Like", "input": "/assort?fw0=0&fbsj0=0&novelbefavoritedcount0=0&yc0=0&xx0=0&mainview1=1&sd0=0&lx0=0&bq=&removebq=&isfinish=0&collectiontypes=ors&searchkeywords=&page={0}&sortType=5", "script": "gen.js"},
        {"title": "Hoàn thành điểm cao", "input": "/assort?fw0=0&fbsj0=0&novelbefavoritedcount0=0&yc0=0&xx0=0&mainview1=1&sd0=0&lx0=0&bq=&removebq=&isfinish=0&collectiontypes=ors&searchkeywords=&page={0}&sortType=10", "script": "gen.js"},
        {"title": "Size", "input": "/assort?fw0=0&fbsj0=0&novelbefavoritedcount0=0&yc0=0&xx0=0&mainview1=1&sd0=0&lx0=0&bq=&removebq=&isfinish=0&collectiontypes=ors&searchkeywords=&page={0}&sortType=4", "script": "gen.js"},
        {"title": "Điểm cao", "input": "/assort?fw0=0&fbsj0=0&novelbefavoritedcount0=0&yc0=0&xx0=0&mainview1=1&sd0=0&lx0=0&bq=&removebq=&isfinish=0&collectiontypes=ors&searchkeywords=&page={0}&sortType=2", "script": "gen.js"},
    ]);
}