load('libs.js');
load('config.js');

function execute(url, page) {
    return Response.success([{
        name: '诸天聊天群从西游开始'.convertT2S(),
        link: 'https://m.jjwxc.net/book2/7717868',
    }]);
}