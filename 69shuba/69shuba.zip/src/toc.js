load('libs.js');
load('config.js');

function execute(url) {
    try {
        var isSTV = url.indexOf("sangtacviet") !== -1 || url.indexOf("14.225.254.182") !== -1;
        var book_id = extractBookId(url, isSTV);

        var browser = Engine.newBrowser(); // Khởi tạo browser
        browser.launch(BASE_URL + '/book/' + book_id + '/', 5000);
        var doc = browser.html(); // Trả về Document object của trang web
        browser.close();

        var data = [];
        var elems = $.QA(doc, 'div.catalog > ul > li');

        if (!elems.length) return trySTV(url);

        var seenIds = {};
        for (var i = 0; i < elems.length; i++) {
            var e = $.Q(elems[i], "a:not(#bookcase)");
            var id = elems[i].attr('data-num');
            if (!seenIds[id] && $.QA(elems[i], "a:not(#bookcase)").length) { 
                data.push({
                    name: formatName(e.text()),
                    url: e.attr('href'),
                    host: BASE_URL,
                    id: id
                });
                seenIds[id] = true;
            }
        }

        // data = data.reverse();

        return Response.success(data);
    } catch (error) {
        return Response.error('fetch ' + url + ' failed: ' + error.message);
    }
}

function formatName(name) {
    // Bước 1: Xử lý dạng "1.第1章 ..."
    var reLeading = /^(\d+)\.第(\d+)章\s*/;
    var result = name.replace(reLeading, '第$2章 ');

    // Bước 1.5: Nếu có "第X集 第Y章 ..." → bỏ "第X集"
    var reEpisodeChapter = /第[一二三四五六七八九十百千\d]+集\s*(第[一二三四五六七八九十百千\d]+章\s*)/;
    result = result.replace(reEpisodeChapter, '$1');

    // Bước 2: Chuẩn hóa dạng "第1章 1xxx" → "第1章 xxx"
    var reDuplicate = /^第([0-9]+)章\s+\1\s*(.*)$/;
    if (reDuplicate.test(result)) {
        result = result.replace(reDuplicate, '第$1章 $2');
    }

    // Bước 3: Cắt bỏ phần ngoặc (...) hoặc （...）
    var lastParenIndex = Math.max(result.lastIndexOf('('), result.lastIndexOf('（'));
    if (lastParenIndex !== -1) {
        result = result.slice(0, lastParenIndex);
    }

    // Bước 4: Nếu chỉ còn "第X章 【...】", thì return luôn
    var onlyBracket = /^第\d+章\s*【[^】]*】?\s*$/;
    if (onlyBracket.test(result)) {
        return result.trim();
    }

    // Bước 5: Xóa phần sau "【"
    result = result.replace(/【.*$/, '');

    // Bước 6: Chuyển từ phồn thể sang giản thể
    return convertT2S(result.trim());
}

function trySTV(url) {
    try {
        var result = [];
        var isSTV = url.indexOf("sangtacviet") !== -1 || url.indexOf("14.225.254.182") !== -1;
        var book_id = extractBookId(url, isSTV);

        tryUrl = STVHOST + '/index.php?ngmar=chapterlist&h=69shu&bookid=' + book_id + '&sajax=getchapterlist';

        var response = fetch(tryUrl, {
            method: 'GET',
            headers: {
                'Accept': '*/*',
                'Referer': STVHOST + "/truyen/69shu/1/" + book_id,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
            }
        });

        if (!response.ok) Response.error("Error try STV: status" + response.status);

        var objData = JSON.parse(response.text());

        if (objData.code != '1') Response.error("Error try STV: x.code" + objData.code);

        var chapters = objData.data.split("-//-");

        for (var i = 0; i < chapters.length; i++) {
            var parts = chapters[i].split("-/-");
            var chapterId = parts[1];
            var chapterName = parts[2];

            result.push({
                name: chapterName.trim().replace(/([\t\n]+|<br>| )/g, "").replace(/([\t\n]+|<br>|&nbsp;)/g, "").replace(/Thứ ([\d\,]+) chương/, "Chương $1:"),
                url: BASE_URL + '/txt/' + book_id + '/' + chapterId,
                host: "",
                id: chapterId
            });
        }

        return Response.success(result);
    } catch (error) {
        return Response.error("Error try STV: " + error.message);
    }
}
