load('libs.js');
load('config.js');
load('gbk.js');
load('stv.js');

function execute(url) {
    try {
        var isSTV = url.indexOf("sangtacviet") !== -1 || url.indexOf("14.225.254.182") !== -1 || url.indexOf("103.82.20.93") !== -1;
        var source = isSTV ? "STV" : "69shu"
        var bookid = extractBookId(url, isSTV);
        url = buildFinalUrl(bookid);

        var browser = Engine.newBrowser(); // Khởi tạo browser
        browser.launch(url, 5000); // Mở trang web với timeout

        browser.callJs(
            "var div = document.createElement('div');" +
            "div.id = 'div-book-infor';" +
            "div.setAttribute('tagsData', (typeof bookinfo !== 'undefined' && bookinfo && bookinfo.tags) ? bookinfo.tags : '');" +
            "document.body.appendChild(div);",
            100
        );

        var doc = browser.html();
        browser.close();

        if ($.Q(doc, 'div.booknav2 > h1 > a').text() === '') return getDetailSTV(`${STVHOST}/truyen/69shu/1/${bookid}/`);

        var genres = buildGenres(doc) || [];

        var bookName = $.Q(doc, 'div.booknav2 > h1 > a').text();
        var cover = buildCover(bookid);

        return Response.success({
            name: bookName,
            cover: cover,
            author: $.Q(doc, 'div.booknav2 > p:nth-child(2) > a').text(),
            description: $.Q(doc, 'div.navtxt > p') ? $.Q(doc, 'div.navtxt > p').html() : '',
            detail: $.QA(doc, 'div.booknav2 p', {
                m: function (x) { return x.text().indexOf("更新") == 0 ? x.text() : ""; }, j: '<br>'
            })
                + '<br>BookId: 【' + bookid + '】'
                + '<br>Source: 【' + source + '】<br>',
            host: BASE_URL,
            suggests: [
                {
                    title: "同作者",
                    input: encodeAuthorUrl($.Q(doc, 'div.booknav2 > p:nth-child(2) > a') ? $.Q(doc, 'div.booknav2 > p:nth-child(2) > a').attr("href") : ''),
                    script: "author.js"
                },
                {
                    title: "Nguồn khác",
                    input: JSON.stringify({
                        name: bookName,
                        cover: cover,
                        url: isSTV ? url : (STVHOST + "/truyen/69shu/1/" + bookid + "/"),
                        source: (isSTV ? "69shuba" : "STV"),
                    }),
                    script: "otherurl.js"
                },
            ],
            genres: genres,
            comments: [
                {
                    title: "评论",
                    input: bookid,
                    script: "comment.js"
                },
                {
                    title: "QQ Comments",
                    input: bookName,
                    script: "qqcomment.js"
                },
            ]
        });
    } catch (error) {
        return Response.error(`Url: ${url} \nMessage: ${error.message}`);
    }
}

function buildFinalUrl(bookid) {
    return BASE_URL + '/book/' + bookid + '.htm';
}

function buildGenres(doc) {
    var genres = [];

    var mainGenreEl = $.Q(doc, 'div.booknav2 > p:nth-child(3) > a');
    if (mainGenreEl && mainGenreEl.text()) {
        genres.push({
            title: mainGenreEl.text().trim(),
            input: mainGenreEl.attr("href"),
            script: "classify.js"
        });
    }

    var tagStr = doc.select("#div-book-infor") && doc.select("#div-book-infor").attr('tagsData') || '';
    var tags = tagStr.split("|");

    for (var i = 0; i < tags.length; i++) {
        var tag = tags[i];
        if (tag) {
            genres.push({
                title: tag,
                input: '/' + tag + '/{0}/',
                script: "gen2.js"
            });
        }
    }

    return genres;
}

function encodeAuthorUrl(url) {
    if (!url) return "";
    var baseUrl = "https://www.69shuba.com/modules/article/author.php?author=";
    var author = GBK.encode(url.replace(baseUrl, ""));
    return baseUrl + author;
}