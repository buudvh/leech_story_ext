function execute() {
    return Response.success([
        { title: "诸天", input: "诸天", script: "search.js" },
        { title: "聊天群", input: "聊天群", script: "search.js" },
        { title: "万界", input: "万界", script: "search.js" },
        { title: "无限", input: "无限", script: "search.js" },

        //Thần Đông
        { title: "神墓", input: "神墓", script: "search.js" },
        { title: "遮天", input: "遮天", script: "search.js" },
        { title: "完美世界", input: "完美世界", script: "search.js" },
        { title: "圣墟", input: "圣墟", script: "search.js" },

        { title: "吞噬", input: "吞噬", script: "search.js" },
        { title: "凡人", input: "凡人", script: "search.js" },

        { title: "一世之尊", input: "一世之尊", script: "search.js" },
        { title: "诡秘", input: "诡秘", script: "search.js" },

        { title: "西游", input: "西游", script: "search.js" },
        { title: "大奉", input: "大奉", script: "search.js" },
        { title: "轮回", input: "轮回", script: "search.js" },
        { title: "庆余年", input: "庆余年", script: "search.js" },
        { title: "斗罗", input: "斗罗", script: "search.js" },
        { title: "斗破", input: "斗破", script: "search.js" },
        { title: "妖神记", input: "妖神记", script: "search.js" },
        { title: "师兄啊", input: "师兄啊", script: "search.js" },
        { title: "全職法師", input: "全職法師", script: "search.js" },
        { title: "剑来", input: "剑来", script: "search.js" },
        { title: "雪中", input: "雪中", script: "search.js" },
        { title: "全球高武", input: "全球高武", script: "search.js" },
        { title: "万族之劫", input: "万族之劫", script: "search.js" },
        { title: "星门", input: "星门", script: "search.js" },

        //Harry Potter
        { title: "哈利波特", input: "哈利波特", script: "search.js" },

        //Anime
        { title: "龙珠", input: "龙珠", script: "search.js" },
        { title: "火影", input: "火影", script: "search.js" },
        { title: "木叶", input: "火影", script: "search.js" },
        { title: "鸣人", input: "鸣人", script: "search.js" },
        { title: "犬夜叉", input: "犬夜叉", script: "search.js" },
        { title: "海贼", input: "海贼", script: "search.js" },
        { title: "妖尾", input: "妖尾", script: "search.js" },
        { title: "奥特曼", input: "奥特曼", script: "search.js" },
        { title: "假面骑士", input: "假面骑士", script: "search.js" },
        { title: "骑士", input: "骑士", script: "search.js" },
        { title: "死神", input: "死神", script: "search.js" },
        { title: "全職獵人", input: "全職獵人", script: "search.js" },
        
        { "title": "玄幻", "input": "/list/玄幻.html", "script": "gen.js" },
        { "title": "奇幻", "input": "/list/奇幻.html", "script": "gen.js" },
        { "title": "武侠", "input": "/list/武侠.html", "script": "gen.js" },
        { "title": "仙侠", "input": "/list/仙侠.html", "script": "gen.js" },
        { "title": "都市", "input": "/list/都市.html", "script": "gen.js" },
        { "title": "言情", "input": "/list/言情.html", "script": "gen.js" },
        { "title": "军事", "input": "/list/军事.html", "script": "gen.js" },
        { "title": "历史", "input": "/list/历史.html", "script": "gen.js" },
        { "title": "科幻", "input": "/list/科幻.html", "script": "gen.js" },
        { "title": "悬疑", "input": "/list/悬疑.html", "script": "gen.js" }
    ]);
}
