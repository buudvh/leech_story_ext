function execute() {
    return Response.success([
        { "title": "Top new", "input": "topnew", "script": "gen2.js" },
        { "title": "Top week", "input": "topweek", "script": "gen2.js" },
        { "title": "Top month", "input": "topmonth", "script": "gen2.js" },
        { "title": "Top all", "input": "topall", "script": "gen2.js" },
        { "title": "玄幻", "input": "/list/玄幻.html", "script": "gen.js" },
        { "title": "奇幻", "input": "/list/奇幻.html", "script": "gen.js" },
        { "title": "武侠", "input": "/list/武侠.html", "script": "gen.js" },
        { "title": "仙侠", "input": "/list/仙侠.html", "script": "gen.js" },
        { "title": "都市", "input": "/list/都市.html", "script": "gen.js" },
        { "title": "言情", "input": "/list/言情.html", "script": "gen.js" },
        { "title": "军事", "input": "/list/军事.html", "script": "gen.js" },
        { "title": "历史", "input": "/list/历史.html", "script": "gen.js" },
        { "title": "科幻", "input": "/list/科幻.html", "script": "gen.js" },
        { "title": "悬疑", "input": "/list/悬疑.html", "script": "gen.js" }
    ]);
}