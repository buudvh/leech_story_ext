load('libs.js');
load('config.js');

//-------TEST GEN.JS--------//
function execute(url) {
    return Response.success([
        {
            name: "御兽飞升",
            link: 'https://www.dxmwx.org/book/57173.html',
            cover: 'https://www.dxmwx.org/images/dxmid/57173.jpg',
            description: "Test",
            host: BASE_URL
        }
    ]);
}